#ifndef IR_ALL_H
#define IR_ALL_H

#include"ir/ir_operand.h"
#include"ir/ir_operator.h"
#include"ir/ir_instruction.h"
#include"ir/ir_function.h"
#include"ir/ir_program.h"

#endif